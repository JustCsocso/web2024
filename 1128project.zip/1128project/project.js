let currentIndex = 0;
let interval;


const startButton = document.getElementById("startButton");
const slideshowContainer = document.querySelector(".slideshow-container");

function showSlides() {
    const slides = document.querySelectorAll(".slide");

   
    slides.forEach(slide => slide.classList.remove("active"));

  
    currentIndex = (currentIndex + 1) % slides.length; 
    slides[currentIndex].classList.add("active");
}


startButton.addEventListener("click", () => {
    startButton.style.display = "none"; 
    slideshowContainer.classList.remove("hidden"); 
    slideshowContainer.style.display = "block"; 

  
    const slides = document.querySelectorAll(".slide");
    if (slides.length > 0) slides[0].classList.add("active");

   
    interval = setInterval(showSlides, 5000);
});
